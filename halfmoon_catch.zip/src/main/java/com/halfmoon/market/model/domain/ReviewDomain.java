package com.halfmoon.market.model.domain;

import com.halfmoon.market.model.ReviewEntity;

public class ReviewDomain extends ReviewEntity {

}
