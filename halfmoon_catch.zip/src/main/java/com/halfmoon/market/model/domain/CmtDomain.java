package com.halfmoon.market.model.domain;

import com.halfmoon.market.model.CmtEntity;

public class CmtDomain extends CmtEntity {
}
