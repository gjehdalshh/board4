package com.halfmoon.market.model.domain;

import com.halfmoon.market.model.LocEntity;

public class LocDomain extends LocEntity{
}
