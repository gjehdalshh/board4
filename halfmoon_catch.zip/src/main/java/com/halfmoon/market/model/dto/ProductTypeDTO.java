package com.halfmoon.market.model.dto;

import com.halfmoon.market.model.ProductTypeEntity;

public class ProductTypeDTO extends ProductTypeEntity{

}
