package com.halfmoon.market.model.dto;

import com.halfmoon.market.model.LocEntity;

public class LocDTO extends LocEntity {
}
